const MassConvert = () => {
  return (
    <>
      <h1>Mass Convert</h1>
    </>
  );
};

export default MassConvert;
