const DataConvert = () => {
  return (
    <>
      <h1>Data Convert</h1>
    </>
  );
};

export default DataConvert;
