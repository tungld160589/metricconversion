const AreaConvert = () => {
  return (
    <>
      <h1>AreaConvert</h1>
    </>
  );
};

export default AreaConvert;
