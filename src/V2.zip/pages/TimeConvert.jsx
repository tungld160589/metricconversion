const TimeConvert = () => {
  return (
    <>
      <h1>Time Convert</h1>
    </>
  );
};

export default TimeConvert;
