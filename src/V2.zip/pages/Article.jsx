const Article = () => {
  return (
    <>
      <h1>Article</h1>
    </>
  );
};

export default Article;
