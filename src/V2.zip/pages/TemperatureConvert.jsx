const TemperatureConvert = () => {
  return (
    <>
      <h1>Temperature Convert</h1>
    </>
  );
};

export default TemperatureConvert;
