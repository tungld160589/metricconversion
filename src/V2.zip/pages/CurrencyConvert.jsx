const CurrencyConvert = () => {
  return (
    <>
      <h1>Currency Convert</h1>
    </>
  );
};

export default CurrencyConvert;
