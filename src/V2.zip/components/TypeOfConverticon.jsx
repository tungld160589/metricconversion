const TypeOfConverticon = (props) => {
  const { rs } = props;
  return (
    <div className={`TypeOfConverticon ${rs.id}`}>
      <div>
        <img src={rs.image} />
      </div>
      <p>{rs.type}</p>
    </div>
  );
};

export default TypeOfConverticon;
