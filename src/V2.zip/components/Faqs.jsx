const Faqs = () => {
  return <div className="Faqs-control"></div>;
};

export default Faqs;
<></>;
