import Nav from "../components/Nav";
import Footer from "../components/Footer";
const Aboutus = () => {
  return (
    <>
      <div>
        <Nav />
      </div>
      <div>Đây là nơi ghi nôi dung</div>
      <div>
        <Footer />
      </div>
    </>
  );
};

export default Aboutus;
